package com.example.demoApp.entity;

import java.util.List;

import javax.persistence.OneToMany;

public class Organization {

	private Long id;
	private String nameString;
	@OneToMany(mappedBy = "organization")
	private List<Employee> employees;
	public Long getId() {
		return id;
	}
	public String getNameString() {
		return nameString;
	}
	public List<Employee> getEmployees() {
		return employees;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public void setNameString(String nameString) {
		this.nameString = nameString;
	}
	public void setEmployees(List<Employee> employees) {
		this.employees = employees;
	}
	public Organization(Long id, String nameString, List<Employee> employees) {
		super();
		this.id = id;
		this.nameString = nameString;
		this.employees = employees;
	}
	public Organization() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Organization(long l, String string) {
		// TODO Auto-generated constructor stub
	
	}
	
	
}
