package com.example.demoApp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demoApp.entity.Employee;
import com.example.demoApp.entity.Organization;
import com.example.demoApp.repo.OrganizationRepository;

@RestController
public class OrganizationController {

	@Autowired
	private OrganizationRepository organizationRepository;

	// get all employees based on organization
	@GetMapping("/organizations/{id}")
	public List<Employee> getAllEmployeesList(@PathVariable Long idLong) {

		Organization organization = organizationRepository.findById(idLong).get();
		return organization.getEmployees();

	}

	@GetMapping("/organizations")
	public List<Organization> getAllOrganizations() {
		return organizationRepository.findAll();
	}

	@PostMapping("/organizations")
	public Organization createOrganization(@RequestBody Organization organization) {
		return organizationRepository.save(organization);
	}

	@PutMapping("/organizations/{organizationId}")
	public void updateOrganization(@PathVariable Long organizationId, @RequestBody Organization organizationRequest) {
		Organization organization = organizationRepository.findById(organizationId).get();
		organization.setNameString(organizationRequest.getNameString());
		organizationRepository.save(organization);
	}

	@DeleteMapping("/organizations/{organizationId}")
	public void deleteOrganization(@PathVariable Long organizationId) {
		organizationRepository.deleteById(organizationId);
	}

}
