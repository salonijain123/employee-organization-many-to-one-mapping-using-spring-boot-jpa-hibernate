package com.example.demoApp.entity;

 import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
 
 @Entity
 public class Employee {
    
	 private Long id;
	 private String nameString;
	 @ManyToOne(fetch = FetchType.LAZY)
	 @JoinColumn(name = "organization_id")
	 
     private Organization organization;
	public Long getId() {
		return id;
	}
	public String getNameString() {
		return nameString;
	}
	public Organization getOrganization() {
		return organization;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public void setNameString(String nameString) {
		this.nameString = nameString;
	}
	public void setOrganization(Organization organization) {
		this.organization = organization;
	}
	public Employee(Long id, String nameString, Organization organization) {
		super();
		this.id = id;
		this.nameString = nameString;
		this.organization = organization;
	}
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	 
	 
 	
 	
 
 }

