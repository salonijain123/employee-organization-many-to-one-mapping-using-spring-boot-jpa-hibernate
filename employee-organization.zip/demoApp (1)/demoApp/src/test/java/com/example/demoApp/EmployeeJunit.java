package com.example.demoApp;

import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demoApp.entity.Employee;
import com.example.demoApp.repo.EmployeeRepository;

@SpringBootTest()
class EmployeeJunit {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	EmployeeRepository employeeRepository;

	@Test
	public void getAllEmployees() {
		logger.info("all employee are " + employeeRepository.findAll());
	}

	@Test
	public void createEmployee() {
		Employee employee = new Employee();
		employee.setId(1L);
		employee.setNameString("xyz-Employee");
		employeeRepository.save(employee);
	}

	@Test
	public void updateEmployee() {
		Employee employee = employeeRepository.findById(1L).get();
		Employee employee1 = new Employee();
		employee1.setNameString("new Name");
		employee.setNameString(employee1.getNameString());

		employeeRepository.save(employee1);
	}

	@Test
	public void deleteEmployee() {
		employeeRepository.deleteById(1L);
	}

}
