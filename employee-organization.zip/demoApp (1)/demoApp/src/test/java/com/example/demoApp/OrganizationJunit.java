package com.example.demoApp;

import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.demoApp.entity.Organization;
import com.example.demoApp.repo.OrganizationRepository;

@SpringBootTest()
class OrganizationJunit {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	OrganizationRepository organizationRepository;

	@Test
	public void getAllEmployeesList(@PathVariable Long idLong) {

		Organization organization = organizationRepository.findById(idLong).get();
		logger.info("organiztion based employee list" + organization.getEmployees());

	}

	@Test
	public void getAllOrganizations() {
		logger.info("all organization are " + organizationRepository.findAll());
	}

	@Test

	public void createOrganization() {
		Organization organization = new Organization(1L, "abc-Organization");
		organizationRepository.save(organization);
	}

	@Test
	public void updateOrganization() {
		Organization organization = organizationRepository.findById(1L).get();
		Organization organization1 = new Organization();
		organization1.setNameString("new Name");
		organization.setNameString(organization1.getNameString());

		organizationRepository.save(organization1);
	}

	@Test
	public void deleteOrganization() {
		organizationRepository.deleteById(1L);
	}

}
